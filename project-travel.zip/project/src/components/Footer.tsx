import React from 'react';
import { Palmtree, Facebook, Twitter, Instagram, Youtube, Mail, Phone } from 'lucide-react';

const Footer = () => {
  return (
    <footer className="bg-teal-900 text-white">
      <div className="container mx-auto px-4 py-12 sm:px-6 lg:px-8">
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-8">
          {/* Brand */}
          <div>
            <div className="flex items-center">
              <Palmtree size={24} className="text-teal-300" />
              <span className="ml-2 text-xl font-bold">ThaiJourney</span>
            </div>
            <p className="mt-4 text-teal-100">
              Experience the best of Thailand with our curated itineraries covering Phuket, Krabi, and combined adventures.
            </p>
            <div className="flex space-x-4 mt-6">
              <SocialIcon icon={<Facebook size={18} />} />
              <SocialIcon icon={<Twitter size={18} />} />
              <SocialIcon icon={<Instagram size={18} />} />
              <SocialIcon icon={<Youtube size={18} />} />
            </div>
          </div>
          
          {/* Quick Links */}
          <div>
            <h3 className="text-lg font-semibold mb-4 text-teal-300">Quick Links</h3>
            <ul className="space-y-2">
              <FooterLink href="/" label="Home" />
              <FooterLink href="/itineraries" label="All Itineraries" />
              <FooterLink href="/recommend" label="Get Recommendations" />
              <FooterLink href="/create" label="Create Custom Itinerary" />
            </ul>
          </div>
          
          {/* Destinations */}
          <div>
            <h3 className="text-lg font-semibold mb-4 text-teal-300">Popular Destinations</h3>
            <ul className="space-y-2">
              <FooterLink href="/itineraries?region=Phuket" label="Phuket" />
              <FooterLink href="/itineraries?region=Krabi" label="Krabi" />
              <FooterLink href="/itineraries?region=Phuket+%26+Krabi" label="Phuket & Krabi" />
              <FooterLink href="/itineraries" label="All Destinations" />
            </ul>
          </div>
          
          {/* Contact */}
          <div>
            <h3 className="text-lg font-semibold mb-4 text-teal-300">Contact Us</h3>
            <div className="space-y-4">
              <div className="flex items-start">
                <Mail size={18} className="mt-1 mr-3 flex-shrink-0 text-teal-300" />
                <span>info@thaijourney.com</span>
              </div>
              <div className="flex items-start">
                <Phone size={18} className="mt-1 mr-3 flex-shrink-0 text-teal-300" />
                <span>+66 2 123 4567</span>
              </div>
            </div>
          </div>
        </div>
        
        <div className="border-t border-teal-800 mt-12 pt-8 text-center text-sm text-teal-300">
          <p>&copy; {new Date().getFullYear()} ThaiJourney. All rights reserved.</p>
        </div>
      </div>
    </footer>
  );
};

const SocialIcon = ({ icon }: { icon: React.ReactNode }) => {
  return (
    <a href="#" className="bg-teal-800 p-2 rounded-full hover:bg-teal-700 transition-colors">
      {icon}
    </a>
  );
};

const FooterLink = ({ href, label }: { href: string; label: string }) => {
  return (
    <li>
      <a href={href} className="text-teal-100 hover:text-white transition-colors">
        {label}
      </a>
    </li>
  );
};

export default Footer;