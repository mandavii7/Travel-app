import React, { useState, useEffect } from 'react';
import { Link, useLocation } from 'react-router-dom';
import { motion } from 'framer-motion';
import { Palmtree, Menu, X } from 'lucide-react';

const Header = () => {
  const [isScrolled, setIsScrolled] = useState(false);
  const [isMenuOpen, setIsMenuOpen] = useState(false);
  const location = useLocation();

  // Track scroll position to change header style
  useEffect(() => {
    const handleScroll = () => {
      setIsScrolled(window.scrollY > 10);
    };
    
    window.addEventListener('scroll', handleScroll);
    return () => window.removeEventListener('scroll', handleScroll);
  }, []);

  // Close mobile menu when route changes
  useEffect(() => {
    setIsMenuOpen(false);
  }, [location]);

  return (
    <header 
      className={`sticky top-0 z-50 transition-all duration-300 ${
        isScrolled ? 'bg-white shadow-md py-2' : 'bg-transparent py-4'
      }`}
    >
      <div className="container mx-auto px-4 sm:px-6 lg:px-8">
        <div className="flex items-center justify-between">
          {/* Logo */}
          <Link to="/" className="flex items-center">
            <Palmtree size={28} className="text-teal-600" />
            <span className="ml-2 text-xl font-bold text-teal-900">ThaiJourney</span>
          </Link>
          
          {/* Desktop Navigation */}
          <nav className="hidden md:flex items-center space-x-8">
            <NavLink to="/" label="Home" isScrolled={isScrolled} />
            <NavLink to="/itineraries" label="Itineraries" isScrolled={isScrolled} />
            <NavLink to="/recommend" label="Get Recommendations" isScrolled={isScrolled} />
            <NavLink to="/create" label="Create Itinerary" isScrolled={isScrolled} />
          </nav>
          
          {/* Mobile Menu Button */}
          <button 
            className="md:hidden flex items-center" 
            onClick={() => setIsMenuOpen(!isMenuOpen)}
          >
            {isMenuOpen ? (
              <X size={24} className="text-teal-900" />
            ) : (
              <Menu size={24} className="text-teal-900" />
            )}
          </button>
        </div>
      </div>
      
      {/* Mobile Menu */}
      {isMenuOpen && (
        <motion.div 
          className="md:hidden bg-white"
          initial={{ opacity: 0, height: 0 }}
          animate={{ opacity: 1, height: 'auto' }}
          exit={{ opacity: 0, height: 0 }}
          transition={{ duration: 0.3 }}
        >
          <div className="container mx-auto px-4 py-4 flex flex-col space-y-4">
            <MobileNavLink to="/" label="Home" />
            <MobileNavLink to="/itineraries" label="Itineraries" />
            <MobileNavLink to="/recommend" label="Get Recommendations" />
            <MobileNavLink to="/create" label="Create Itinerary" />
          </div>
        </motion.div>
      )}
    </header>
  );
};

// Nav link with active state
const NavLink = ({ to, label, isScrolled }: { to: string; label: string; isScrolled: boolean }) => {
  const location = useLocation();
  const isActive = location.pathname === to;
  
  return (
    <Link
      to={to}
      className={`relative py-2 font-medium transition-colors ${
        isActive
          ? 'text-teal-600'
          : isScrolled
          ? 'text-teal-900 hover:text-teal-600'
          : 'text-teal-900 hover:text-teal-600'
      }`}
    >
      {label}
      {isActive && (
        <motion.div
          layoutId="underline"
          className="absolute left-0 right-0 bottom-0 h-0.5 bg-teal-600"
        />
      )}
    </Link>
  );
};

// Mobile nav link
const MobileNavLink = ({ to, label }: { to: string; label: string }) => {
  const location = useLocation();
  const isActive = location.pathname === to;
  
  return (
    <Link
      to={to}
      className={`py-2 font-medium ${
        isActive ? 'text-teal-600' : 'text-teal-900'
      }`}
    >
      {label}
    </Link>
  );
};

export default Header;