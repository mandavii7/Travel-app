import React, { useState, useEffect } from 'react';
import { useParams, useNavigate } from 'react-router-dom';
import { motion } from 'framer-motion';
import { Calendar, Clock, MapPin, Hotel, Car, Navigation, Activity } from 'lucide-react';
import axios from 'axios';

interface Activity {
  id: number;
  name: string;
  location: string;
  description: string;
  duration_minutes: number;
}

interface Transfer {
  id: number;
  from_location: string;
  to_location: string;
  transport_type: string;
  duration_minutes: number;
}

interface Accommodation {
  id: number;
  name: string;
  location: string;
  description: string;
}

interface ItineraryDay {
  id: number;
  day_number: number;
  accommodation: Accommodation | null;
  transfers: Transfer[];
  activities: Activity[];
}

interface Itinerary {
  id: number;
  title: string;
  description: string;
  duration_nights: number;
  region: string;
  price: number;
  days: ItineraryDay[];
}

const ItineraryDetailPage = () => {
  const { id } = useParams<{ id: string }>();
  const navigate = useNavigate();
  const [itinerary, setItinerary] = useState<Itinerary | null>(null);
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState('');
  const [activeDay, setActiveDay] = useState(1);
  
  useEffect(() => {
    const fetchItinerary = async () => {
      try {
        setLoading(true);
        const response = await axios.get(`http://localhost:8000/itineraries/${id}`);
        setItinerary(response.data);
        setLoading(false);
      } catch (err) {
        console.error('Error fetching itinerary:', err);
        setError('Failed to load itinerary. Please try again later.');
        setLoading(false);
      }
    };
    
    fetchItinerary();
  }, [id]);
  
  if (loading) {
    return (
      <div className="min-h-screen flex justify-center items-center">
        <div className="animate-spin rounded-full h-12 w-12 border-b-2 border-teal-600"></div>
      </div>
    );
  }
  
  if (error || !itinerary) {
    return (
      <div className="container mx-auto px-4 py-12 sm:px-6 lg:px-8">
        <div className="bg-red-50 text-red-800 p-6 rounded-lg">
          <h2 className="text-xl font-semibold mb-2">Error</h2>
          <p>{error || 'Itinerary not found'}</p>
          <button
            onClick={() => navigate('/itineraries')}
            className="mt-4 inline-flex items-center px-4 py-2 border border-transparent text-sm font-medium rounded-md text-white bg-teal-600 hover:bg-teal-700"
          >
            Back to Itineraries
          </button>
        </div>
      </div>
    );
  }
  
  // Choose an image based on the region
  let headerImageUrl;
  if (itinerary.region === 'Phuket') {
    headerImageUrl = 'https://images.pexels.com/photos/1659438/pexels-photo-1659438.jpeg';
  } else if (itinerary.region === 'Krabi') {
    headerImageUrl = 'https://images.pexels.com/photos/2559941/pexels-photo-2559941.jpeg';
  } else {
    headerImageUrl = 'https://images.pexels.com/photos/1770310/pexels-photo-1770310.jpeg';
  }
  
  // Sort days by day number
  const sortedDays = [...itinerary.days].sort((a, b) => a.day_number - b.day_number);
  const currentDay = sortedDays.find(day => day.day_number === activeDay) || sortedDays[0];
  
  return (
    <div>
      {/* Hero Section */}
      <div className="relative h-80 overflow-hidden">
        <img 
          src={headerImageUrl} 
          alt={itinerary.title} 
          className="w-full h-full object-cover"
        />
        <div className="absolute inset-0 bg-gradient-to-t from-black to-transparent opacity-70"></div>
        <div className="absolute bottom-0 left-0 w-full p-6 sm:p-10">
          <div className="container mx-auto">
            <div className="flex items-center text-white mb-2">
              <MapPin size={18} className="mr-2" />
              <span className="font-medium">{itinerary.region}</span>
              <span className="mx-2">•</span>
              <Calendar size={18} className="mr-2" />
              <span className="font-medium">{itinerary.duration_nights} Nights</span>
            </div>
            <h1 className="text-3xl sm:text-4xl font-bold text-white mb-2">
              {itinerary.title}
            </h1>
            <div className="bg-teal-600 text-white py-1 px-3 rounded-full inline-flex items-center">
              <span className="font-bold">${itinerary.price}</span>
            </div>
          </div>
        </div>
      </div>
      
      <div className="container mx-auto px-4 py-10 sm:px-6 lg:px-8">
        <div className="grid grid-cols-1 lg:grid-cols-3 gap-10">
          <div className="lg:col-span-2">
            {/* Description */}
            <div className="mb-10">
              <h2 className="text-2xl font-bold text-gray-900 mb-4">Itinerary Overview</h2>
              <p className="text-gray-700 leading-relaxed">{itinerary.description}</p>
            </div>
            
            {/* Day Tabs */}
            <div className="mb-8">
              <h2 className="text-2xl font-bold text-gray-900 mb-4">Day-by-Day Schedule</h2>
              <div className="flex overflow-x-auto pb-2 space-x-2">
                {sortedDays.map((day) => (
                  <button
                    key={day.id}
                    onClick={() => setActiveDay(day.day_number)}
                    className={`flex-shrink-0 px-4 py-2 rounded-lg font-medium transition-colors ${
                      activeDay === day.day_number
                        ? 'bg-teal-600 text-white'
                        : 'bg-gray-100 text-gray-700 hover:bg-gray-200'
                    }`}
                  >
                    Day {day.day_number}
                  </button>
                ))}
              </div>
            </div>
            
            {/* Day Details */}
            {currentDay && (
              <div className="bg-white rounded-lg shadow-md p-6 mb-8">
                <h3 className="text-xl font-bold text-gray-900 mb-4">
                  Day {currentDay.day_number} {currentDay.day_number === itinerary.duration_nights + 1 ? '(Departure)' : ''}
                </h3>
                
                {/* Accommodation */}
                {currentDay.accommodation && (
                  <motion.div 
                    className="mb-6 border-l-4 border-blue-500 pl-4"
                    initial={{ opacity: 0, x: -10 }}
                    animate={{ opacity: 1, x: 0 }}
                    transition={{ duration: 0.3 }}
                  >
                    <div className="flex items-center text-blue-600 mb-2">
                      <Hotel size={18} className="mr-2" />
                      <h4 className="font-semibold">Accommodation</h4>
                    </div>
                    <div className="bg-blue-50 p-4 rounded-md">
                      <h5 className="font-bold text-gray-900">{currentDay.accommodation.name}</h5>
                      <div className="text-sm text-gray-600 mb-2 flex items-center">
                        <MapPin size={14} className="mr-1" />
                        {currentDay.accommodation.location}
                      </div>
                      <p className="text-gray-700">{currentDay.accommodation.description}</p>
                    </div>
                  </motion.div>
                )}
                
                {/* Activities */}
                {currentDay.activities.length > 0 && (
                  <motion.div 
                    className="mb-6 border-l-4 border-amber-500 pl-4"
                    initial={{ opacity: 0, x: -10 }}
                    animate={{ opacity: 1, x: 0 }}
                    transition={{ duration: 0.3, delay: 0.1 }}
                  >
                    <div className="flex items-center text-amber-600 mb-2">
                      <Activity size={18} className="mr-2" />
                      <h4 className="font-semibold">Activities</h4>
                    </div>
                    <div className="space-y-4">
                      {currentDay.activities.map((activity) => (
                        <div key={activity.id} className="bg-amber-50 p-4 rounded-md">
                          <h5 className="font-bold text-gray-900">{activity.name}</h5>
                          <div className="flex justify-between text-sm text-gray-600 mb-2">
                            <div className="flex items-center">
                              <MapPin size={14} className="mr-1" />
                              {activity.location}
                            </div>
                            <div className="flex items-center">
                              <Clock size={14} className="mr-1" />
                              {Math.floor(activity.duration_minutes / 60)}h {activity.duration_minutes % 60}m
                            </div>
                          </div>
                          <p className="text-gray-700">{activity.description}</p>
                        </div>
                      ))}
                    </div>
                  </motion.div>
                )}
                
                {/* Transfers */}
                {currentDay.transfers.length > 0 && (
                  <motion.div 
                    className="mb-6 border-l-4 border-green-500 pl-4"
                    initial={{ opacity: 0, x: -10 }}
                    animate={{ opacity: 1, x: 0 }}
                    transition={{ duration: 0.3, delay: 0.2 }}
                  >
                    <div className="flex items-center text-green-600 mb-2">
                      <Car size={18} className="mr-2" />
                      <h4 className="font-semibold">Transfers</h4>
                    </div>
                    <div className="space-y-4">
                      {currentDay.transfers.map((transfer) => (
                        <div key={transfer.id} className="bg-green-50 p-4 rounded-md">
                          <div className="flex items-center justify-between mb-2">
                            <span className="font-medium text-gray-900">{transfer.transport_type}</span>
                            <span className="text-sm text-gray-600 flex items-center">
                              <Clock size={14} className="mr-1" />
                              {Math.floor(transfer.duration_minutes / 60)}h {transfer.duration_minutes % 60}m
                            </span>
                          </div>
                          <div className="flex items-center justify-between text-sm">
                            <div className="flex-1">
                              <div className="flex items-center text-gray-700">
                                <div className="h-2 w-2 rounded-full bg-green-500 mr-2"></div>
                                {transfer.from_location}
                              </div>
                            </div>
                            <div className="mx-2">
                              <Navigation size={14} className="text-gray-400 transform rotate-90" />
                            </div>
                            <div className="flex-1 text-right">
                              <div className="flex items-center justify-end text-gray-700">
                                {transfer.to_location}
                                <div className="h-2 w-2 rounded-full bg-red-500 ml-2"></div>
                              </div>
                            </div>
                          </div>
                        </div>
                      ))}
                    </div>
                  </motion.div>
                )}
                
                {currentDay.activities.length === 0 && currentDay.transfers.length === 0 && !currentDay.accommodation && (
                  <div className="text-gray-600 italic">
                    Departure day. Check out and transfer to the airport.
                  </div>
                )}
              </div>
            )}
          </div>
          
          {/* Sidebar */}
          <div className="lg:col-span-1">
            <div className="bg-white rounded-lg shadow-md p-6 sticky top-24">
              <h3 className="text-xl font-bold text-gray-900 mb-4">Itinerary Summary</h3>
              
              <div className="space-y-4 mb-6">
                <div className="flex items-center">
                  <div className="bg-teal-100 p-2 rounded-full mr-3">
                    <MapPin size={18} className="text-teal-600" />
                  </div>
                  <div>
                    <h4 className="text-sm font-medium text-gray-500">Destination</h4>
                    <p className="font-medium">{itinerary.region}</p>
                  </div>
                </div>
                
                <div className="flex items-center">
                  <div className="bg-teal-100 p-2 rounded-full mr-3">
                    <Calendar size={18} className="text-teal-600" />
                  </div>
                  <div>
                    <h4 className="text-sm font-medium text-gray-500">Duration</h4>
                    <p className="font-medium">{itinerary.duration_nights} Nights / {itinerary.duration_nights + 1} Days</p>
                  </div>
                </div>
                
                <div className="flex items-center">
                  <div className="bg-teal-100 p-2 rounded-full mr-3">
                    <Hotel size={18} className="text-teal-600" />
                  </div>
                  <div>
                    <h4 className="text-sm font-medium text-gray-500">Accommodations</h4>
                    <p className="font-medium">{itinerary.days.filter(day => day.accommodation).length} Hotels</p>
                  </div>
                </div>
                
                <div className="flex items-center">
                  <div className="bg-teal-100 p-2 rounded-full mr-3">
                    <Activity size={18} className="text-teal-600" />
                  </div>
                  <div>
                    <h4 className="text-sm font-medium text-gray-500">Activities</h4>
                    <p className="font-medium">
                      {itinerary.days.reduce((sum, day) => sum + day.activities.length, 0)} Activities
                    </p>
                  </div>
                </div>
              </div>
              
              <div className="border-t border-gray-200 pt-6">
                <div className="flex justify-between mb-2">
                  <span className="text-gray-600">Base price</span>
                  <span className="font-medium">${itinerary.price}</span>
                </div>
                <div className="flex justify-between mb-2">
                  <span className="text-gray-600">Taxes & fees</span>
                  <span className="font-medium">${Math.round(itinerary.price * 0.1)}</span>
                </div>
                <div className="flex justify-between font-bold text-lg mt-4">
                  <span>Total</span>
                  <span>${Math.round(itinerary.price * 1.1)}</span>
                </div>
              </div>
              
              <button className="w-full bg-teal-600 hover:bg-teal-700 text-white font-medium py-3 px-4 rounded-lg mt-6 transition-colors">
                Book This Itinerary
              </button>
              
              <p className="text-xs text-gray-500 mt-4 text-center">
                Secure your booking with a 20% deposit today
              </p>
            </div>
          </div>
        </div>
        
        {/* Similar Itineraries */}
        <div className="mt-16">
          <h2 className="text-2xl font-bold text-gray-900 mb-6">You Might Also Like</h2>
          <button 
            onClick={() => navigate(`/recommend/${itinerary.duration_nights}`)}
            className="inline-flex items-center px-6 py-3 mb-8 border border-transparent text-base font-medium rounded-md text-white bg-teal-600 hover:bg-teal-700"
          >
            View More {itinerary.duration_nights}-Night Itineraries
          </button>
        </div>
      </div>
    </div>
  );
};

export default ItineraryDetailPage;