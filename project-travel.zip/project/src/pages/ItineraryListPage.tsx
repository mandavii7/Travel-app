import React, { useState, useEffect } from 'react';
import { useLocation, useNavigate } from 'react-router-dom';
import { motion } from 'framer-motion';
import { Calendar, Filter, Search, MapPin, X } from 'lucide-react';
import axios from 'axios';

interface Itinerary {
  id: number;
  title: string;
  description: string;
  duration_nights: number;
  region: string;
  price: number;
}

const ItineraryListPage = () => {
  const [itineraries, setItineraries] = useState<Itinerary[]>([]);
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState('');
  const [filteredItineraries, setFilteredItineraries] = useState<Itinerary[]>([]);
  
  const location = useLocation();
  const navigate = useNavigate();
  const queryParams = new URLSearchParams(location.search);
  const regionFilter = queryParams.get('region');
  
  const [filters, setFilters] = useState({
    region: regionFilter || 'all',
    duration: 'all',
    minPrice: '',
    maxPrice: '',
    searchTerm: ''
  });
  
  useEffect(() => {
    const fetchItineraries = async () => {
      try {
        setLoading(true);
        const response = await axios.get('http://localhost:8000/itineraries/');
        setItineraries(response.data);
        setLoading(false);
      } catch (err) {
        console.error('Error fetching itineraries:', err);
        setError('Failed to load itineraries. Please try again later.');
        setLoading(false);
      }
    };
    
    fetchItineraries();
  }, []);
  
  // Apply filters when itineraries or filters change
  useEffect(() => {
    let result = [...itineraries];
    
    // Region filter
    if (filters.region !== 'all') {
      result = result.filter(item => item.region === filters.region);
    }
    
    // Duration filter
    if (filters.duration !== 'all') {
      const duration = parseInt(filters.duration);
      result = result.filter(item => item.duration_nights === duration);
    }
    
    // Price range filter
    if (filters.minPrice) {
      const minPrice = parseFloat(filters.minPrice);
      result = result.filter(item => item.price >= minPrice);
    }
    
    if (filters.maxPrice) {
      const maxPrice = parseFloat(filters.maxPrice);
      result = result.filter(item => item.price <= maxPrice);
    }
    
    // Search term filter
    if (filters.searchTerm) {
      const term = filters.searchTerm.toLowerCase();
      result = result.filter(
        item => 
          item.title.toLowerCase().includes(term) || 
          item.description.toLowerCase().includes(term) ||
          item.region.toLowerCase().includes(term)
      );
    }
    
    setFilteredItineraries(result);
  }, [itineraries, filters]);
  
  const handleFilterChange = (e: React.ChangeEvent<HTMLSelectElement | HTMLInputElement>) => {
    const { name, value } = e.target;
    setFilters(prev => ({
      ...prev,
      [name]: value
    }));
    
    // Update URL for region filter
    if (name === 'region' && value !== 'all') {
      navigate(`/itineraries?region=${value}`, { replace: true });
    } else if (name === 'region' && value === 'all') {
      navigate('/itineraries', { replace: true });
    }
  };
  
  const handleSearch = (e: React.FormEvent) => {
    e.preventDefault();
  };
  
  const clearFilters = () => {
    setFilters({
      region: 'all',
      duration: 'all',
      minPrice: '',
      maxPrice: '',
      searchTerm: ''
    });
    navigate('/itineraries', { replace: true });
  };
  
  return (
    <div className="container mx-auto px-4 py-12 sm:px-6 lg:px-8">
      <div className="text-center mb-12">
        <h1 className="text-3xl font-bold text-gray-900 mb-4">Browse Thailand Itineraries</h1>
        <p className="text-xl text-gray-600 max-w-3xl mx-auto">
          Discover our carefully curated travel plans featuring the best of Phuket, Krabi, and combined trips.
        </p>
      </div>
      
      {/* Filters Section */}
      <div className="bg-white rounded-lg shadow-md p-6 mb-8">
        <div className="flex items-center justify-between mb-4">
          <div className="flex items-center">
            <Filter size={20} className="text-teal-600 mr-2" />
            <h2 className="text-xl font-semibold text-gray-900">Filters</h2>
          </div>
          {(filters.region !== 'all' || 
            filters.duration !== 'all' || 
            filters.minPrice || 
            filters.maxPrice || 
            filters.searchTerm) && (
            <button 
              onClick={clearFilters}
              className="text-sm text-gray-600 hover:text-teal-600 flex items-center"
            >
              <X size={16} className="mr-1" />
              Clear Filters
            </button>
          )}
        </div>
        
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-5 gap-4">
          {/* Region Filter */}
          <div>
            <label htmlFor="region" className="block text-sm font-medium text-gray-700 mb-1">
              Region
            </label>
            <select
              id="region"
              name="region"
              value={filters.region}
              onChange={handleFilterChange}
              className="block w-full rounded-md border-gray-300 shadow-sm focus:ring-teal-500 focus:border-teal-500 sm:text-sm bg-white border p-2"
            >
              <option value="all">All Regions</option>
              <option value="Phuket">Phuket</option>
              <option value="Krabi">Krabi</option>
              <option value="Phuket & Krabi">Phuket & Krabi</option>
            </select>
          </div>
          
          {/* Duration Filter */}
          <div>
            <label htmlFor="duration" className="block text-sm font-medium text-gray-700 mb-1">
              Duration
            </label>
            <select
              id="duration"
              name="duration"
              value={filters.duration}
              onChange={handleFilterChange}
              className="block w-full rounded-md border-gray-300 shadow-sm focus:ring-teal-500 focus:border-teal-500 sm:text-sm bg-white border p-2"
            >
              <option value="all">Any Duration</option>
              <option value="2">2 Nights</option>
              <option value="3">3 Nights</option>
              <option value="4">4 Nights</option>
              <option value="5">5 Nights</option>
              <option value="6">6 Nights</option>
              <option value="7">7 Nights</option>
              <option value="8">8 Nights</option>
            </select>
          </div>
          
          {/* Min Price Filter */}
          <div>
            <label htmlFor="minPrice" className="block text-sm font-medium text-gray-700 mb-1">
              Min Price ($)
            </label>
            <input
              type="number"
              id="minPrice"
              name="minPrice"
              value={filters.minPrice}
              onChange={handleFilterChange}
              placeholder="Min"
              className="block w-full rounded-md border-gray-300 shadow-sm focus:ring-teal-500 focus:border-teal-500 sm:text-sm border p-2"
            />
          </div>
          
          {/* Max Price Filter */}
          <div>
            <label htmlFor="maxPrice" className="block text-sm font-medium text-gray-700 mb-1">
              Max Price ($)
            </label>
            <input
              type="number"
              id="maxPrice"
              name="maxPrice"
              value={filters.maxPrice}
              onChange={handleFilterChange}
              placeholder="Max"
              className="block w-full rounded-md border-gray-300 shadow-sm focus:ring-teal-500 focus:border-teal-500 sm:text-sm border p-2"
            />
          </div>
          
          {/* Search */}
          <div>
            <label htmlFor="searchTerm" className="block text-sm font-medium text-gray-700 mb-1">
              Search
            </label>
            <div className="relative">
              <input
                type="text"
                id="searchTerm"
                name="searchTerm"
                value={filters.searchTerm}
                onChange={handleFilterChange}
                placeholder="Search itineraries..."
                className="block w-full rounded-md border-gray-300 shadow-sm focus:ring-teal-500 focus:border-teal-500 sm:text-sm pl-10 border p-2"
              />
              <div className="absolute inset-y-0 left-0 pl-3 flex items-center pointer-events-none">
                <Search size={16} className="text-gray-400" />
              </div>
            </div>
          </div>
        </div>
      </div>
      
      {/* Results */}
      <div>
        <div className="flex justify-between items-center mb-6">
          <h2 className="text-xl font-semibold text-gray-900">
            {loading ? 'Loading...' : `${filteredItineraries.length} Itineraries Found`}
          </h2>
        </div>
        
        {loading ? (
          <div className="flex justify-center py-12">
            <div className="animate-spin rounded-full h-12 w-12 border-b-2 border-teal-600"></div>
          </div>
        ) : error ? (
          <div className="bg-red-50 text-red-800 p-4 rounded-md">
            {error}
          </div>
        ) : filteredItineraries.length === 0 ? (
          <div className="bg-gray-50 text-gray-800 p-8 rounded-md text-center">
            <p className="text-lg font-medium">No itineraries found matching your filters.</p>
            <button 
              onClick={clearFilters}
              className="mt-4 inline-flex items-center px-4 py-2 border border-transparent text-sm font-medium rounded-md text-white bg-teal-600 hover:bg-teal-700"
            >
              Clear Filters
            </button>
          </div>
        ) : (
          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
            {filteredItineraries.map(itinerary => (
              <ItineraryCard key={itinerary.id} itinerary={itinerary} />
            ))}
          </div>
        )}
      </div>
    </div>
  );
};

const ItineraryCard = ({ itinerary }: { itinerary: Itinerary }) => {
  const navigate = useNavigate();
  
  // Choose an image based on the region
  let imageUrl;
  if (itinerary.region === 'Phuket') {
    imageUrl = 'https://images.pexels.com/photos/1659438/pexels-photo-1659438.jpeg';
  } else if (itinerary.region === 'Krabi') {
    imageUrl = 'https://images.pexels.com/photos/2559941/pexels-photo-2559941.jpeg';
  } else {
    imageUrl = 'https://images.pexels.com/photos/1770310/pexels-photo-1770310.jpeg';
  }
  
  return (
    <motion.div 
      className="bg-white rounded-lg overflow-hidden shadow-md hover:shadow-lg transition-shadow"
      whileHover={{ y: -5 }}
      transition={{ duration: 0.3 }}
      onClick={() => navigate(`/itineraries/${itinerary.id}`)}
    >
      <div className="h-48 relative">
        <img src={imageUrl} alt={itinerary.title} className="w-full h-full object-cover" />
        <div className="absolute top-0 left-0 w-full h-full bg-gradient-to-b from-transparent to-black opacity-60"></div>
        <div className="absolute bottom-4 left-4 flex items-center text-white">
          <MapPin size={16} className="mr-1" />
          <span className="font-medium">{itinerary.region}</span>
        </div>
        <div className="absolute top-4 right-4 bg-teal-600 text-white text-sm font-medium px-3 py-1 rounded-full flex items-center">
          <Calendar size={14} className="mr-1" />
          {itinerary.duration_nights} Nights
        </div>
      </div>
      <div className="p-6">
        <h3 className="text-lg font-bold text-gray-900 mb-2">{itinerary.title}</h3>
        <p className="text-gray-600 text-sm mb-4 line-clamp-2">{itinerary.description}</p>
        <div className="flex justify-between items-center">
          <div className="font-bold text-teal-600">${itinerary.price}</div>
          <button 
            onClick={(e) => {
              e.stopPropagation();
              navigate(`/itineraries/${itinerary.id}`);
            }}
            className="text-sm text-teal-700 font-medium hover:text-teal-800 flex items-center"
          >
            View Details
            <svg className="ml-1 w-4 h-4" fill="none" stroke="currentColor" viewBox="0 0 24 24" xmlns="http://www.w3.org/2000/svg">
              <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M9 5l7 7-7 7" />
            </svg>
          </button>
        </div>
      </div>
    </motion.div>
  );
};

export default ItineraryListPage;