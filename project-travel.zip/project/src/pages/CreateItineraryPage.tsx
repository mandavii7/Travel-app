import React, { useState } from 'react';
import { useNavigate } from 'react-router-dom';
import { motion } from 'framer-motion';
import { Calendar, MapPin, PlusCircle, MinusCircle, Send } from 'lucide-react';
import axios from 'axios';

interface ActivityFormData {
  name: string;
  location: string;
  description: string;
  duration_minutes: number;
}

interface TransferFormData {
  from_location: string;
  to_location: string;
  transport_type: string;
  duration_minutes: number;
}

interface AccommodationFormData {
  name: string;
  location: string;
  description: string;
}

interface DayFormData {
  day_number: number;
  accommodation: AccommodationFormData | null;
  transfers: TransferFormData[];
  activities: ActivityFormData[];
}

interface ItineraryFormData {
  title: string;
  description: string;
  duration_nights: number;
  region: string;
  price: number;
  is_recommended: boolean;
  days: DayFormData[];
}

const CreateItineraryPage = () => {
  const navigate = useNavigate();
  const [loading, setLoading] = useState(false);
  const [error, setError] = useState('');
  const [success, setSuccess] = useState(false);
  const [createdItineraryId, setCreatedItineraryId] = useState<number | null>(null);
  
  const [formData, setFormData] = useState<ItineraryFormData>({
    title: '',
    description: '',
    duration_nights: 3,
    region: 'Phuket',
    price: 0,
    is_recommended: false,
    days: []
  });
  
  // Initialize days when duration changes
  const initializeDays = (nights: number) => {
    const newDays: DayFormData[] = [];
    
    for (let i = 1; i <= nights + 1; i++) {
      newDays.push({
        day_number: i,
        accommodation: i <= nights ? {
          name: '',
          location: '',
          description: ''
        } : null,
        transfers: [],
        activities: []
      });
    }
    
    return newDays;
  };
  
  // Initialize days on first render
  React.useEffect(() => {
    setFormData(prev => ({
      ...prev,
      days: initializeDays(prev.duration_nights)
    }));
  }, []);
  
  const handleBasicInfoChange = (e: React.ChangeEvent<HTMLInputElement | HTMLTextAreaElement | HTMLSelectElement>) => {
    const { name, value, type } = e.target;
    
    if (name === 'duration_nights') {
      const nights = parseInt(value);
      setFormData({
        ...formData,
        [name]: nights,
        days: initializeDays(nights)
      });
    } else if (name === 'price') {
      setFormData({
        ...formData,
        [name]: parseFloat(value)
      });
    } else if (name === 'is_recommended' && type === 'checkbox') {
      setFormData({
        ...formData,
        [name]: (e.target as HTMLInputElement).checked
      });
    } else {
      setFormData({
        ...formData,
        [name]: value
      });
    }
  };
  
  const handleAccommodationChange = (dayIndex: number, e: React.ChangeEvent<HTMLInputElement | HTMLTextAreaElement>) => {
    const { name, value } = e.target;
    const newDays = [...formData.days];
    
    if (newDays[dayIndex].accommodation) {
      newDays[dayIndex].accommodation = {
        ...newDays[dayIndex].accommodation!,
        [name]: value
      };
    }
    
    setFormData({
      ...formData,
      days: newDays
    });
  };
  
  const handleActivityChange = (dayIndex: number, activityIndex: number, e: React.ChangeEvent<HTMLInputElement | HTMLTextAreaElement>) => {
    const { name, value } = e.target;
    const newDays = [...formData.days];
    
    if (name === 'duration_minutes') {
      newDays[dayIndex].activities[activityIndex] = {
        ...newDays[dayIndex].activities[activityIndex],
        [name]: parseInt(value)
      };
    } else {
      newDays[dayIndex].activities[activityIndex] = {
        ...newDays[dayIndex].activities[activityIndex],
        [name]: value
      };
    }
    
    setFormData({
      ...formData,
      days: newDays
    });
  };
  
  const handleTransferChange = (dayIndex: number, transferIndex: number, e: React.ChangeEvent<HTMLInputElement | HTMLSelectElement>) => {
    const { name, value } = e.target;
    const newDays = [...formData.days];
    
    if (name === 'duration_minutes') {
      newDays[dayIndex].transfers[transferIndex] = {
        ...newDays[dayIndex].transfers[transferIndex],
        [name]: parseInt(value)
      };
    } else {
      newDays[dayIndex].transfers[transferIndex] = {
        ...newDays[dayIndex].transfers[transferIndex],
        [name]: value
      };
    }
    
    setFormData({
      ...formData,
      days: newDays
    });
  };
  
  const addActivity = (dayIndex: number) => {
    const newDays = [...formData.days];
    newDays[dayIndex].activities.push({
      name: '',
      location: '',
      description: '',
      duration_minutes: 60
    });
    
    setFormData({
      ...formData,
      days: newDays
    });
  };
  
  const removeActivity = (dayIndex: number, activityIndex: number) => {
    const newDays = [...formData.days];
    newDays[dayIndex].activities.splice(activityIndex, 1);
    
    setFormData({
      ...formData,
      days: newDays
    });
  };
  
  const addTransfer = (dayIndex: number) => {
    const newDays = [...formData.days];
    newDays[dayIndex].transfers.push({
      from_location: '',
      to_location: '',
      transport_type: 'Private car',
      duration_minutes: 30
    });
    
    setFormData({
      ...formData,
      days: newDays
    });
  };
  
  const removeTransfer = (dayIndex: number, transferIndex: number) => {
    const newDays = [...formData.days];
    newDays[dayIndex].transfers.splice(transferIndex, 1);
    
    setFormData({
      ...formData,
      days: newDays
    });
  };
  
  const validateForm = () => {
    if (!formData.title) return 'Please enter a title';
    if (!formData.description) return 'Please enter a description';
    if (formData.price <= 0) return 'Please enter a valid price';
    
    // Check each day
    for (let i = 0; i < formData.days.length; i++) {
      const day = formData.days[i];
      
      // Check accommodation (except for last day)
      if (i < formData.duration_nights) {
        if (!day.accommodation) return `Day ${i + 1}: Please add accommodation details`;
        if (!day.accommodation.name) return `Day ${i + 1}: Please enter accommodation name`;
        if (!day.accommodation.location) return `Day ${i + 1}: Please enter accommodation location`;
        if (!day.accommodation.description) return `Day ${i + 1}: Please enter accommodation description`;
      }
      
      // Check activities
      for (let j = 0; j < day.activities.length; j++) {
        const activity = day.activities[j];
        if (!activity.name) return `Day ${i + 1}, Activity ${j + 1}: Please enter activity name`;
        if (!activity.location) return `Day ${i + 1}, Activity ${j + 1}: Please enter activity location`;
        if (!activity.description) return `Day ${i + 1}, Activity ${j + 1}: Please enter activity description`;
        if (activity.duration_minutes <= 0) return `Day ${i + 1}, Activity ${j + 1}: Please enter a valid duration`;
      }
      
      // Check transfers
      for (let j = 0; j < day.transfers.length; j++) {
        const transfer = day.transfers[j];
        if (!transfer.from_location) return `Day ${i + 1}, Transfer ${j + 1}: Please enter departure location`;
        if (!transfer.to_location) return `Day ${i + 1}, Transfer ${j + 1}: Please enter destination location`;
        if (!transfer.transport_type) return `Day ${i + 1}, Transfer ${j + 1}: Please select transport type`;
        if (transfer.duration_minutes <= 0) return `Day ${i + 1}, Transfer ${j + 1}: Please enter a valid duration`;
      }
    }
    
    return '';
  };
  
  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    
    const validationError = validateForm();
    if (validationError) {
      setError(validationError);
      return;
    }
    
    try {
      setLoading(true);
      setError('');
      
      const response = await axios.post('http://localhost:8000/itineraries/', formData);
      setCreatedItineraryId(response.data.id);
      setSuccess(true);
      setLoading(false);
      
      // Scroll to top
      window.scrollTo({ top: 0, behavior: 'smooth' });
      
    } catch (err) {
      console.error('Error creating itinerary:', err);
      setError('Failed to create itinerary. Please try again.');
      setLoading(false);
    }
  };
  
  if (success && createdItineraryId) {
    return (
      <div className="container mx-auto px-4 py-12 sm:px-6 lg:px-8">
        <div className="max-w-2xl mx-auto bg-white rounded-lg shadow-md p-8 text-center">
          <div className="bg-green-100 text-green-800 p-4 rounded-full inline-flex items-center justify-center mb-6">
            <svg className="w-12 h-12" fill="none" stroke="currentColor" viewBox="0 0 24 24" xmlns="http://www.w3.org/2000/svg">
              <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M5 13l4 4L19 7" />
            </svg>
          </div>
          <h2 className="text-2xl font-bold text-gray-900 mb-4">Itinerary Created Successfully!</h2>
          <p className="text-gray-600 mb-8">
            Your itinerary "{formData.title}" has been created and is now available.
          </p>
          <div className="flex flex-col sm:flex-row gap-4 justify-center">
            <button
              onClick={() => navigate(`/itineraries/${createdItineraryId}`)}
              className="inline-flex items-center justify-center px-6 py-3 border border-transparent text-base font-medium rounded-md text-white bg-teal-600 hover:bg-teal-700"
            >
              View Itinerary
            </button>
            <button
              onClick={() => {
                setSuccess(false);
                setCreatedItineraryId(null);
                setFormData({
                  title: '',
                  description: '',
                  duration_nights: 3,
                  region: 'Phuket',
                  price: 0,
                  is_recommended: false,
                  days: initializeDays(3)
                });
              }}
              className="inline-flex items-center justify-center px-6 py-3 border border-gray-300 text-base font-medium rounded-md text-gray-700 bg-white hover:bg-gray-50"
            >
              Create Another
            </button>
          </div>
        </div>
      </div>
    );
  }
  
  return (
    <div className="container mx-auto px-4 py-12 sm:px-6 lg:px-8">
      <div className="text-center mb-10">
        <h1 className="text-3xl font-bold text-gray-900 mb-4">Create New Itinerary</h1>
        <p className="text-xl text-gray-600 max-w-3xl mx-auto">
          Build a custom itinerary by filling out the form below with all the details.
        </p>
      </div>
      
      {error && (
        <div className="max-w-4xl mx-auto mb-8 bg-red-50 text-red-800 p-4 rounded-md">
          {error}
        </div>
      )}
      
      <form onSubmit={handleSubmit} className="max-w-4xl mx-auto">
        {/* Basic Information */}
        <div className="bg-white rounded-lg shadow-md p-6 mb-8">
          <h2 className="text-xl font-semibold text-gray-900 mb-4">Basic Information</h2>
          
          <div className="grid grid-cols-1 md:grid-cols-2 gap-6 mb-6">
            <div>
              <label htmlFor="title" className="block text-sm font-medium text-gray-700 mb-1">
                Title*
              </label>
              <input
                type="text"
                id="title"
                name="title"
                value={formData.title}
                onChange={handleBasicInfoChange}
                placeholder="e.g., Phuket Adventure"
                className="block w-full rounded-md border-gray-300 shadow-sm focus:ring-teal-500 focus:border-teal-500 sm:text-sm border p-2"
                required
              />
            </div>
            
            <div>
              <label htmlFor="region" className="block text-sm font-medium text-gray-700 mb-1">
                Region*
              </label>
              <select
                id="region"
                name="region"
                value={formData.region}
                onChange={handleBasicInfoChange}
                className="block w-full rounded-md border-gray-300 shadow-sm focus:ring-teal-500 focus:border-teal-500 sm:text-sm border p-2"
                required
              >
                <option value="Phuket">Phuket</option>
                <option value="Krabi">Krabi</option>
                <option value="Phuket & Krabi">Phuket & Krabi</option>
              </select>
            </div>
          </div>
          
          <div className="mb-6">
            <label htmlFor="description" className="block text-sm font-medium text-gray-700 mb-1">
              Description*
            </label>
            <textarea
              id="description"
              name="description"
              value={formData.description}
              onChange={handleBasicInfoChange}
              rows={4}
              placeholder="Describe this itinerary..."
              className="block w-full rounded-md border-gray-300 shadow-sm focus:ring-teal-500 focus:border-teal-500 sm:text-sm border p-2"
              required
            />
          </div>
          
          <div className="grid grid-cols-1 md:grid-cols-3 gap-6">
            <div>
              <label htmlFor="duration_nights" className="block text-sm font-medium text-gray-700 mb-1">
                Duration (Nights)*
              </label>
              <select
                id="duration_nights"
                name="duration_nights"
                value={formData.duration_nights}
                onChange={handleBasicInfoChange}
                className="block w-full rounded-md border-gray-300 shadow-sm focus:ring-teal-500 focus:border-teal-500 sm:text-sm border p-2"
                required
              >
                <option value="2">2 Nights</option>
                <option value="3">3 Nights</option>
                <option value="4">4 Nights</option>
                <option value="5">5 Nights</option>
                <option value="6">6 Nights</option>
                <option value="7">7 Nights</option>
                <option value="8">8 Nights</option>
              </select>
            </div>
            
            <div>
              <label htmlFor="price" className="block text-sm font-medium text-gray-700 mb-1">
                Price ($)*
              </label>
              <input
                type="number"
                id="price"
                name="price"
                value={formData.price}
                onChange={handleBasicInfoChange}
                min="0"
                step="0.01"
                className="block w-full rounded-md border-gray-300 shadow-sm focus:ring-teal-500 focus:border-teal-500 sm:text-sm border p-2"
                required
              />
            </div>
            
            <div className="flex items-center h-full pt-6">
              <input
                type="checkbox"
                id="is_recommended"
                name="is_recommended"
                checked={formData.is_recommended}
                onChange={handleBasicInfoChange}
                className="h-4 w-4 text-teal-600 focus:ring-teal-500 border-gray-300 rounded"
              />
              <label htmlFor="is_recommended" className="ml-2 block text-sm text-gray-700">
                Feature as Recommended
              </label>
            </div>
          </div>
        </div>
        
        {/* Day-by-Day Itinerary */}
        <div className="space-y-8">
          {formData.days.map((day, dayIndex) => (
            <div key={dayIndex} className="bg-white rounded-lg shadow-md p-6">
              <h2 className="text-xl font-semibold text-gray-900 mb-4">
                Day {day.day_number} {day.day_number === formData.duration_nights + 1 ? '(Departure)' : ''}
              </h2>
              
              {/* Accommodation (not for last day) */}
              {dayIndex < formData.duration_nights && (
                <div className="mb-8">
                  <h3 className="text-md font-medium text-gray-800 mb-4 flex items-center">
                    <Hotel size={18} className="mr-2 text-blue-600" />
                    Accommodation
                  </h3>
                  
                  <div className="bg-blue-50 p-4 rounded-md">
                    <div className="grid grid-cols-1 md:grid-cols-2 gap-4 mb-4">
                      <div>
                        <label htmlFor={`day${dayIndex}-acc-name`} className="block text-sm font-medium text-gray-700 mb-1">
                          Hotel Name*
                        </label>
                        <input
                          type="text"
                          id={`day${dayIndex}-acc-name`}
                          name="name"
                          value={day.accommodation?.name || ''}
                          onChange={(e) => handleAccommodationChange(dayIndex, e)}
                          className="block w-full rounded-md border-gray-300 shadow-sm focus:ring-blue-500 focus:border-blue-500 sm:text-sm border p-2"
                          required
                        />
                      </div>
                      
                      <div>
                        <label htmlFor={`day${dayIndex}-acc-location`} className="block text-sm font-medium text-gray-700 mb-1">
                          Location*
                        </label>
                        <input
                          type="text"
                          id={`day${dayIndex}-acc-location`}
                          name="location"
                          value={day.accommodation?.location || ''}
                          onChange={(e) => handleAccommodationChange(dayIndex, e)}
                          className="block w-full rounded-md border-gray-300 shadow-sm focus:ring-blue-500 focus:border-blue-500 sm:text-sm border p-2"
                          required
                        />
                      </div>
                    </div>
                    
                    <div>
                      <label htmlFor={`day${dayIndex}-acc-description`} className="block text-sm font-medium text-gray-700 mb-1">
                        Description*
                      </label>
                      <textarea
                        id={`day${dayIndex}-acc-description`}
                        name="description"
                        value={day.accommodation?.description || ''}
                        onChange={(e) => handleAccommodationChange(dayIndex, e)}
                        rows={2}
                        className="block w-full rounded-md border-gray-300 shadow-sm focus:ring-blue-500 focus:border-blue-500 sm:text-sm border p-2"
                        required
                      />
                    </div>
                  </div>
                </div>
              )}
              
              {/* Activities */}
              <div className="mb-8">
                <div className="flex justify-between items-center mb-4">
                  <h3 className="text-md font-medium text-gray-800 flex items-center">
                    <Activity size={18} className="mr-2 text-amber-600" />
                    Activities
                  </h3>
                  
                  <button
                    type="button"
                    onClick={() => addActivity(dayIndex)}
                    className="inline-flex items-center px-3 py-1 border border-transparent text-sm font-medium rounded-md text-amber-700 bg-amber-100 hover:bg-amber-200"
                  >
                    <PlusCircle size={16} className="mr-1" />
                    Add Activity
                  </button>
                </div>
                
                {day.activities.length === 0 ? (
                  <div className="text-center py-4 bg-gray-50 rounded-md text-gray-500">
                    No activities added yet
                  </div>
                ) : (
                  <div className="space-y-4">
                    {day.activities.map((activity, activityIndex) => (
                      <div key={activityIndex} className="bg-amber-50 p-4 rounded-md relative">
                        <button
                          type="button"
                          onClick={() => removeActivity(dayIndex, activityIndex)}
                          className="absolute top-2 right-2 text-gray-500 hover:text-red-600"
                        >
                          <MinusCircle size={16} />
                        </button>
                        
                        <div className="grid grid-cols-1 md:grid-cols-2 gap-4 mb-4">
                          <div>
                            <label htmlFor={`day${dayIndex}-act${activityIndex}-name`} className="block text-sm font-medium text-gray-700 mb-1">
                              Activity Name*
                            </label>
                            <input
                              type="text"
                              id={`day${dayIndex}-act${activityIndex}-name`}
                              name="name"
                              value={activity.name}
                              onChange={(e) => handleActivityChange(dayIndex, activityIndex, e)}
                              className="block w-full rounded-md border-gray-300 shadow-sm focus:ring-amber-500 focus:border-amber-500 sm:text-sm border p-2"
                              required
                            />
                          </div>
                          
                          <div>
                            <label htmlFor={`day${dayIndex}-act${activityIndex}-location`} className="block text-sm font-medium text-gray-700 mb-1">
                              Location*
                            </label>
                            <input
                              type="text"
                              id={`day${dayIndex}-act${activityIndex}-location`}
                              name="location"
                              value={activity.location}
                              onChange={(e) => handleActivityChange(dayIndex, activityIndex, e)}
                              className="block w-full rounded-md border-gray-300 shadow-sm focus:ring-amber-500 focus:border-amber-500 sm:text-sm border p-2"
                              required
                            />
                          </div>
                        </div>
                        
                        <div className="mb-4">
                          <label htmlFor={`day${dayIndex}-act${activityIndex}-description`} className="block text-sm font-medium text-gray-700 mb-1">
                            Description*
                          </label>
                          <textarea
                            id={`day${dayIndex}-act${activityIndex}-description`}
                            name="description"
                            value={activity.description}
                            onChange={(e) => handleActivityChange(dayIndex, activityIndex, e)}
                            rows={2}
                            className="block w-full rounded-md border-gray-300 shadow-sm focus:ring-amber-500 focus:border-amber-500 sm:text-sm border p-2"
                            required
                          />
                        </div>
                        
                        <div>
                          <label htmlFor={`day${dayIndex}-act${activityIndex}-duration`} className="block text-sm font-medium text-gray-700 mb-1">
                            Duration (minutes)*
                          </label>
                          <input
                            type="number"
                            id={`day${dayIndex}-act${activityIndex}-duration`}
                            name="duration_minutes"
                            value={activity.duration_minutes}
                            onChange={(e) => handleActivityChange(dayIndex, activityIndex, e)}
                            min="1"
                            className="block w-full md:w-1/3 rounded-md border-gray-300 shadow-sm focus:ring-amber-500 focus:border-amber-500 sm:text-sm border p-2"
                            required
                          />
                        </div>
                      </div>
                    ))}
                  </div>
                )}
              </div>
              
              {/* Transfers */}
              <div>
                <div className="flex justify-between items-center mb-4">
                  <h3 className="text-md font-medium text-gray-800 flex items-center">
                    <Car size={18} className="mr-2 text-green-600" />
                    Transfers
                  </h3>
                  
                  <button
                    type="button"
                    onClick={() => addTransfer(dayIndex)}
                    className="inline-flex items-center px-3 py-1 border border-transparent text-sm font-medium rounded-md text-green-700 bg-green-100 hover:bg-green-200"
                  >
                    <PlusCircle size={16} className="mr-1" />
                    Add Transfer
                  </button>
                </div>
                
                {day.transfers.length === 0 ? (
                  <div className="text-center py-4 bg-gray-50 rounded-md text-gray-500">
                    No transfers added yet
                  </div>
                ) : (
                  <div className="space-y-4">
                    {day.transfers.map((transfer, transferIndex) => (
                      <div key={transferIndex} className="bg-green-50 p-4 rounded-md relative">
                        <button
                          type="button"
                          onClick={() => removeTransfer(dayIndex, transferIndex)}
                          className="absolute top-2 right-2 text-gray-500 hover:text-red-600"
                        >
                          <MinusCircle size={16} />
                        </button>
                        
                        <div className="grid grid-cols-1 md:grid-cols-2 gap-4 mb-4">
                          <div>
                            <label htmlFor={`day${dayIndex}-trans${transferIndex}-from`} className="block text-sm font-medium text-gray-700 mb-1">
                              From*
                            </label>
                            <input
                              type="text"
                              id={`day${dayIndex}-trans${transferIndex}-from`}
                              name="from_location"
                              value={transfer.from_location}
                              onChange={(e) => handleTransferChange(dayIndex, transferIndex, e)}
                              className="block w-full rounded-md border-gray-300 shadow-sm focus:ring-green-500 focus:border-green-500 sm:text-sm border p-2"
                              required
                            />
                          </div>
                          
                          <div>
                            <label htmlFor={`day${dayIndex}-trans${transferIndex}-to`} className="block text-sm font-medium text-gray-700 mb-1">
                              To*
                            </label>
                            <input
                              type="text"
                              id={`day${dayIndex}-trans${transferIndex}-to`}
                              name="to_location"
                              value={transfer.to_location}
                              onChange={(e) => handleTransferChange(dayIndex, transferIndex, e)}
                              className="block w-full rounded-md border-gray-300 shadow-sm focus:ring-green-500 focus:border-green-500 sm:text-sm border p-2"
                              required
                            />
                          </div>
                        </div>
                        
                        <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                          <div>
                            <label htmlFor={`day${dayIndex}-trans${transferIndex}-type`} className="block text-sm font-medium text-gray-700 mb-1">
                              Transport Type*
                            </label>
                            <select
                              id={`day${dayIndex}-trans${transferIndex}-type`}
                              name="transport_type"
                              value={transfer.transport_type}
                              onChange={(e) => handleTransferChange(dayIndex, transferIndex, e)}
                              className="block w-full rounded-md border-gray-300 shadow-sm focus:ring-green-500 focus:border-green-500 sm:text-sm border p-2"
                              required
                            >
                              <option value="Private car">Private car</option>
                              <option value="Minivan">Minivan</option>
                              <option value="Speedboat">Speedboat</option>
                              <option value="Ferry">Ferry</option>
                              <option value="Longtail boat">Longtail boat</option>
                            </select>
                          </div>
                          
                          <div>
                            <label htmlFor={`day${dayIndex}-trans${transferIndex}-duration`} className="block text-sm font-medium text-gray-700 mb-1">
                              Duration (minutes)*
                            </label>
                            <input
                              type="number"
                              id={`day${dayIndex}-trans${transferIndex}-duration`}
                              name="duration_minutes"
                              value={transfer.duration_minutes}
                              onChange={(e) => handleTransferChange(dayIndex, transferIndex, e)}
                              min="1"
                              className="block w-full rounded-md border-gray-300 shadow-sm focus:ring-green-500 focus:border-green-500 sm:text-sm border p-2"
                              required
                            />
                          </div>
                        </div>
                      </div>
                    ))}
                  </div>
                )}
              </div>
            </div>
          ))}
        </div>
        
        {/* Submit Button */}
        <div className="mt-8 flex justify-center">
          <button
            type="submit"
            disabled={loading}
            className={`inline-flex items-center px-6 py-3 border border-transparent text-base font-medium rounded-md text-white bg-teal-600 hover:bg-teal-700 focus:outline-none focus:ring-2 focus:ring-offset-2 focus:ring-teal-500 ${
              loading ? 'opacity-70 cursor-not-allowed' : ''
            }`}
          >
            {loading ? (
              <>
                <div className="animate-spin rounded-full h-4 w-4 border-b-2 border-white mr-2"></div>
                Creating...
              </>
            ) : (
              <>
                <Send size={18} className="mr-2" />
                Create Itinerary
              </>
            )}
          </button>
        </div>
      </form>
    </div>
  );
};

const Hotel = Calendar;  // Use Calendar icon as Hotel

export default CreateItineraryPage;