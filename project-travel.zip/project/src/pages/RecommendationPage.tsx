import React, { useState, useEffect } from 'react';
import { useParams, useNavigate } from 'react-router-dom';
import { motion } from 'framer-motion';
import { Calendar, MapPin, Search } from 'lucide-react';
import axios from 'axios';

interface RecommendedItinerary {
  id: number;
  title: string;
  description: string;
  duration_nights: number;
  region: string;
  price: number;
}

const RecommendationPage = () => {
  const { nights } = useParams<{ nights?: string }>();
  const navigate = useNavigate();
  const [duration, setDuration] = useState(nights ? parseInt(nights) : 3);
  const [itineraries, setItineraries] = useState<RecommendedItinerary[]>([]);
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState('');
  
  useEffect(() => {
    if (nights) {
      setDuration(parseInt(nights));
    }
  }, [nights]);
  
  useEffect(() => {
    const fetchRecommendations = async () => {
      try {
        setLoading(true);
        const response = await axios.get(`http://localhost:8000/recommended/${duration}`);
        setItineraries(response.data);
        setLoading(false);
      } catch (err) {
        console.error('Error fetching recommendations:', err);
        setError('Failed to load recommendations. Please try again later.');
        setLoading(false);
      }
    };
    
    fetchRecommendations();
  }, [duration]);
  
  const handleDurationChange = (e: React.ChangeEvent<HTMLSelectElement>) => {
    const newDuration = parseInt(e.target.value);
    setDuration(newDuration);
    navigate(`/recommend/${newDuration}`);
  };
  
  return (
    <div className="container mx-auto px-4 py-12 sm:px-6 lg:px-8">
      <div className="text-center mb-10">
        <h1 className="text-3xl font-bold text-gray-900 mb-4">Recommended Itineraries</h1>
        <p className="text-xl text-gray-600 max-w-3xl mx-auto">
          Discover our top recommendations for your Thailand adventure.
        </p>
      </div>
      
      {/* Duration Selector */}
      <div className="max-w-md mx-auto mb-12">
        <div className="bg-white rounded-lg shadow-md p-6">
          <h2 className="text-lg font-semibold text-gray-900 mb-4">How many nights are you staying?</h2>
          <div className="relative">
            <select
              id="duration"
              value={duration}
              onChange={handleDurationChange}
              className="block w-full pl-10 pr-3 py-2 text-gray-700 border border-gray-300 rounded-md shadow-sm focus:outline-none focus:ring-teal-500 focus:border-teal-500"
            >
              <option value="2">2 Nights</option>
              <option value="3">3 Nights</option>
              <option value="4">4 Nights</option>
              <option value="5">5 Nights</option>
              <option value="6">6 Nights</option>
              <option value="7">7 Nights</option>
              <option value="8">8 Nights</option>
            </select>
            <div className="absolute inset-y-0 left-0 pl-3 flex items-center pointer-events-none">
              <Calendar size={18} className="text-gray-500" />
            </div>
          </div>
        </div>
      </div>
      
      {/* Results */}
      <div className="mb-20">
        <h2 className="text-2xl font-bold text-gray-900 mb-6">
          {loading ? 'Finding the perfect itineraries...' : `Top ${itineraries.length} Recommendations for ${duration} Nights`}
        </h2>
        
        {loading ? (
          <div className="flex justify-center py-12">
            <div className="animate-spin rounded-full h-12 w-12 border-b-2 border-teal-600"></div>
          </div>
        ) : error ? (
          <div className="bg-red-50 text-red-800 p-4 rounded-md">
            {error}
          </div>
        ) : itineraries.length === 0 ? (
          <div className="bg-gray-50 text-gray-800 p-8 rounded-md text-center">
            <p className="text-lg font-medium">No recommended itineraries found for {duration} nights.</p>
            <p className="mt-2">Try selecting a different duration or check back later.</p>
          </div>
        ) : (
          <div className="grid grid-cols-1 lg:grid-cols-2 gap-8">
            {itineraries.map(itinerary => (
              <RecommendationCard key={itinerary.id} itinerary={itinerary} />
            ))}
          </div>
        )}
      </div>
      
      {/* Customization CTA */}
      <div className="bg-teal-800 text-white rounded-lg p-8 text-center">
        <h2 className="text-2xl font-bold mb-4">Need a Custom Itinerary?</h2>
        <p className="text-lg mb-6 max-w-2xl mx-auto">
          Don't see what you're looking for? Create a customized itinerary tailored to your preferences.
        </p>
        <button 
          onClick={() => navigate('/create')}
          className="inline-flex items-center px-6 py-3 border border-transparent text-base font-medium rounded-md text-teal-700 bg-white hover:bg-gray-100"
        >
          <Search size={18} className="mr-2" />
          Create Custom Itinerary
        </button>
      </div>
    </div>
  );
};

const RecommendationCard = ({ itinerary }: { itinerary: RecommendedItinerary }) => {
  const navigate = useNavigate();
  
  // Choose an image based on the region
  let imageUrl;
  if (itinerary.region === 'Phuket') {
    imageUrl = 'https://images.pexels.com/photos/1659438/pexels-photo-1659438.jpeg';
  } else if (itinerary.region === 'Krabi') {
    imageUrl = 'https://images.pexels.com/photos/2559941/pexels-photo-2559941.jpeg';
  } else {
    imageUrl = 'https://images.pexels.com/photos/1770310/pexels-photo-1770310.jpeg';
  }
  
  return (
    <motion.div 
      className="bg-white rounded-lg overflow-hidden shadow-md hover:shadow-lg transition-shadow flex flex-col sm:flex-row h-full"
      whileHover={{ y: -5 }}
      transition={{ duration: 0.3 }}
      onClick={() => navigate(`/itineraries/${itinerary.id}`)}
    >
      <div className="sm:w-2/5 h-48 sm:h-auto relative">
        <img src={imageUrl} alt={itinerary.title} className="w-full h-full object-cover" />
        <div className="absolute top-4 right-4 bg-teal-600 text-white text-sm font-medium px-3 py-1 rounded-full flex items-center">
          <Calendar size={14} className="mr-1" />
          {itinerary.duration_nights} Nights
        </div>
      </div>
      <div className="sm:w-3/5 p-6 flex flex-col justify-between">
        <div>
          <div className="flex items-center mb-2">
            <MapPin size={16} className="text-teal-600 mr-1" />
            <span className="text-sm font-medium text-teal-600">{itinerary.region}</span>
          </div>
          <h3 className="text-xl font-bold text-gray-900 mb-2">{itinerary.title}</h3>
          <p className="text-gray-600 mb-4 line-clamp-3">{itinerary.description}</p>
        </div>
        <div className="flex justify-between items-center mt-auto">
          <div className="font-bold text-xl text-teal-600">${itinerary.price}</div>
          <button 
            onClick={(e) => {
              e.stopPropagation();
              navigate(`/itineraries/${itinerary.id}`);
            }}
            className="text-teal-700 font-medium hover:text-teal-800 flex items-center"
          >
            View Details
            <svg className="ml-1 w-4 h-4" fill="none" stroke="currentColor" viewBox="0 0 24 24" xmlns="http://www.w3.org/2000/svg">
              <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M9 5l7 7-7 7" />
            </svg>
          </button>
        </div>
      </div>
    </motion.div>
  );
};

export default RecommendationPage;