import React from 'react';
import { useNavigate } from 'react-router-dom';
import { motion } from 'framer-motion';
import { MapPin, Calendar, Search, Compass, Award, Clock } from 'lucide-react';

const HomePage = () => {
  const navigate = useNavigate();
  const [nights, setNights] = React.useState<string>('3');
  
  const handleGetRecommendations = (e: React.FormEvent) => {
    e.preventDefault();
    navigate(`/recommend/${nights}`);
  };
  
  return (
    <div>
      {/* Hero Section */}
      <section className="relative h-screen min-h-[600px] bg-gradient-to-r from-blue-900 to-teal-900 text-white overflow-hidden">
        <div className="absolute inset-0 z-0">
          <img 
            src="https://images.pexels.com/photos/1450353/pexels-photo-1450353.jpeg" 
            alt="Thailand Beach" 
            className="w-full h-full object-cover opacity-40"
          />
        </div>
        
        <div className="container mx-auto px-4 py-32 sm:px-6 lg:px-8 relative z-10 flex flex-col items-center justify-center h-full text-center">
          <motion.h1 
            className="text-4xl sm:text-5xl md:text-6xl font-bold mb-6"
            initial={{ opacity: 0, y: 20 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ duration: 0.6 }}
          >
            Discover Thailand's Paradise
          </motion.h1>
          
          <motion.p 
            className="text-xl md:text-2xl max-w-3xl mb-12"
            initial={{ opacity: 0, y: 20 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ duration: 0.6, delay: 0.2 }}
          >
            Explore curated itineraries for Phuket, Krabi, and beyond. 
            Your perfect Thai adventure awaits.
          </motion.p>
          
          <motion.div 
            className="max-w-md w-full bg-white rounded-lg shadow-lg p-6"
            initial={{ opacity: 0, y: 20 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ duration: 0.6, delay: 0.4 }}
          >
            <h2 className="text-gray-800 text-xl font-semibold mb-4">Find Your Perfect Trip</h2>
            <form onSubmit={handleGetRecommendations}>
              <div className="space-y-4">
                <div>
                  <label htmlFor="nights" className="block text-sm font-medium text-gray-700 text-left mb-1">
                    Duration
                  </label>
                  <div className="relative">
                    <select
                      id="nights"
                      value={nights}
                      onChange={(e) => setNights(e.target.value)}
                      className="block w-full pl-10 pr-3 py-2 text-gray-700 border border-gray-300 rounded-md shadow-sm focus:outline-none focus:ring-teal-500 focus:border-teal-500"
                    >
                      <option value="2">2 Nights</option>
                      <option value="3">3 Nights</option>
                      <option value="4">4 Nights</option>
                      <option value="5">5 Nights</option>
                      <option value="6">6 Nights</option>
                      <option value="7">7 Nights</option>
                      <option value="8">8 Nights</option>
                    </select>
                    <div className="absolute inset-y-0 left-0 pl-3 flex items-center pointer-events-none">
                      <Calendar size={18} className="text-gray-500" />
                    </div>
                  </div>
                </div>
                
                <button
                  type="submit"
                  className="w-full flex items-center justify-center px-4 py-2 border border-transparent text-base font-medium rounded-md text-white bg-teal-600 hover:bg-teal-700 focus:outline-none focus:ring-2 focus:ring-offset-2 focus:ring-teal-500"
                >
                  <Search size={18} className="mr-2" />
                  Get Recommendations
                </button>
              </div>
            </form>
          </motion.div>
        </div>
      </section>
      
      {/* Features Section */}
      <section className="py-20 bg-white">
        <div className="container mx-auto px-4 sm:px-6 lg:px-8">
          <div className="text-center mb-16">
            <h2 className="text-3xl font-bold text-gray-900">Why Choose Our Itineraries</h2>
            <p className="mt-4 text-xl text-gray-600 max-w-3xl mx-auto">
              We've crafted perfect travel experiences so you can focus on making memories.
            </p>
          </div>
          
          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-8">
            <FeatureCard 
              icon={<Compass size={24} className="text-teal-600" />}
              title="Expert Local Knowledge"
              description="Our itineraries are created by Thailand experts who know the hidden gems and best experiences."
            />
            <FeatureCard 
              icon={<Clock size={24} className="text-teal-600" />}
              title="Time-Saving Planning"
              description="Skip hours of research with our perfectly balanced day-by-day schedules."
            />
            <FeatureCard 
              icon={<Award size={24} className="text-teal-600" />}
              title="Quality Experiences"
              description="We only include the highest-rated activities and accommodations in our itineraries."
            />
          </div>
        </div>
      </section>
      
      {/* Destination Preview */}
      <section className="py-20 bg-gray-50">
        <div className="container mx-auto px-4 sm:px-6 lg:px-8">
          <div className="text-center mb-16">
            <h2 className="text-3xl font-bold text-gray-900">Popular Destinations</h2>
            <p className="mt-4 text-xl text-gray-600 max-w-3xl mx-auto">
              Explore Thailand's most breathtaking locations with our curated itineraries.
            </p>
          </div>
          
          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-2 gap-8">
            <DestinationCard 
              image="https://images.pexels.com/photos/1659438/pexels-photo-1659438.jpeg"
              title="Phuket"
              description="Discover Thailand's largest island with stunning beaches, vibrant nightlife, and cultural attractions."
              nights="2-8 nights"
              onClick={() => navigate('/itineraries?region=Phuket')}
            />
            <DestinationCard 
              image="https://images.pexels.com/photos/2559941/pexels-photo-2559941.jpeg"
              title="Krabi"
              description="Explore limestone cliffs, emerald waters, and pristine beaches in this natural paradise."
              nights="2-8 nights"
              onClick={() => navigate('/itineraries?region=Krabi')}
            />
          </div>
          
          <div className="mt-8">
            <DestinationCard 
              image="https://images.pexels.com/photos/1770310/pexels-photo-1770310.jpeg"
              title="Phuket & Krabi Combined"
              description="Experience the best of both worlds with our combined itineraries featuring these two amazing destinations."
              nights="5-8 nights"
              onClick={() => navigate('/itineraries?region=Phuket+%26+Krabi')}
            />
          </div>
        </div>
      </section>
      
      {/* Call to Action */}
      <section className="bg-teal-800 text-white py-20">
        <div className="container mx-auto px-4 sm:px-6 lg:px-8 text-center">
          <h2 className="text-3xl font-bold mb-6">Ready to Plan Your Thai Adventure?</h2>
          <p className="text-xl max-w-2xl mx-auto mb-10">
            Get personalized itinerary recommendations based on your travel duration.
          </p>
          <button 
            onClick={() => navigate('/recommend')}
            className="inline-flex items-center px-6 py-3 border border-transparent text-base font-medium rounded-md text-teal-700 bg-white hover:bg-gray-100 focus:outline-none focus:ring-2 focus:ring-offset-2 focus:ring-offset-teal-800 focus:ring-white"
          >
            <Search size={18} className="mr-2" />
            Find My Perfect Itinerary
          </button>
        </div>
      </section>
    </div>
  );
};

const FeatureCard = ({ icon, title, description }: { icon: React.ReactNode, title: string, description: string }) => {
  return (
    <motion.div 
      className="bg-white rounded-lg p-6 shadow-sm border border-gray-100 hover:shadow-md transition-shadow"
      whileHover={{ y: -5 }}
      transition={{ duration: 0.3 }}
    >
      <div className="flex flex-col items-center text-center">
        <div className="bg-teal-50 p-3 rounded-full mb-4">
          {icon}
        </div>
        <h3 className="text-xl font-semibold text-gray-900 mb-2">{title}</h3>
        <p className="text-gray-600">{description}</p>
      </div>
    </motion.div>
  );
};

const DestinationCard = ({ 
  image, 
  title, 
  description, 
  nights, 
  onClick 
}: { 
  image: string, 
  title: string, 
  description: string, 
  nights: string,
  onClick: () => void
}) => {
  return (
    <motion.div 
      className="bg-white rounded-lg overflow-hidden shadow-md hover:shadow-lg transition-shadow"
      whileHover={{ scale: 1.02 }}
      transition={{ duration: 0.3 }}
      onClick={onClick}
    >
      <div className="h-64 relative">
        <img src={image} alt={title} className="w-full h-full object-cover" />
        <div className="absolute top-4 right-4 bg-teal-600 text-white text-sm font-medium px-3 py-1 rounded-full flex items-center">
          <Calendar size={14} className="mr-1" />
          {nights}
        </div>
      </div>
      <div className="p-6">
        <div className="flex items-center mb-3">
          <MapPin size={18} className="text-teal-600 mr-2" />
          <h3 className="text-xl font-bold text-gray-900">{title}</h3>
        </div>
        <p className="text-gray-600 mb-4">{description}</p>
        <button 
          onClick={onClick}
          className="inline-flex items-center text-teal-600 font-medium hover:text-teal-800"
        >
          Explore Itineraries
          <svg className="ml-1 w-4 h-4" fill="none" stroke="currentColor" viewBox="0 0 24 24" xmlns="http://www.w3.org/2000/svg">
            <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M9 5l7 7-7 7" />
          </svg>
        </button>
      </div>
    </motion.div>
  );
};

export default HomePage;