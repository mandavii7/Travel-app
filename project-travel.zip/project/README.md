# Thailand Travel Itinerary System

A full-stack application for managing travel itineraries in Thailand, featuring Phuket and Krabi regions.

## Features

- Database architecture for trip itineraries using SQLAlchemy
- RESTful API endpoints with FastAPI for creating and viewing itineraries
- MCP server that provides recommended itineraries based on duration
- Modern React frontend with TypeScript and Tailwind CSS
- Day-by-day itinerary planning with accommodations, transfers, and activities
- Search and filter functionality

## Tech Stack

### Backend
- FastAPI
- SQLAlchemy
- SQLite
- Pydantic

### Frontend
- React
- TypeScript
- Tailwind CSS
- Framer Motion
- Lucide React

## Getting Started

### Prerequisites
- Node.js
- Python 3.8+

### Installation

1. Clone the repository

2. Install frontend dependencies
```
npm install
```

3. Install backend dependencies
```
cd backend
pip install -r requirements.txt
```

4. Seed the database
```
cd backend
python seed.py
```

### Running the Application

1. Start the backend server
```
cd backend
uvicorn main:app --reload
```

2. In a new terminal, start the frontend development server
```
npm run dev
```

## API Documentation

The API documentation is available at `http://localhost:8000/docs` when the backend server is running.

### Key Endpoints

- `GET /itineraries/` - Get all itineraries
- `GET /itineraries/{id}` - Get a specific itinerary
- `POST /itineraries/` - Create a new itinerary
- `GET /recommended/{nights}` - Get recommended itineraries for a specific duration

## Database Schema

The database consists of the following tables:
- `itineraries` - Main itinerary information
- `itinerary_days` - Day-by-day breakdown of itineraries
- `accommodations` - Hotel information for each day
- `transfers` - Transportation details between locations
- `activities` - Activities and excursions for each day

## License

This project is licensed under the MIT License.