from fastapi import FastAPI, HTTPException, Depends
from fastapi.middleware.cors import CORSMiddleware
from typing import List, Optional
import models
from database import engine, SessionLocal
from sqlalchemy.orm import Session
from schemas import ItineraryCreate, Itinerary, RecommendedItinerary

# Create database tables
models.Base.metadata.create_all(bind=engine)

app = FastAPI(title="Travel Itinerary API")

# Configure CORS
app.add_middleware(
    CORSMiddleware,
    allow_origins=["*"],  # In production, replace with specific origins
    allow_credentials=True,
    allow_methods=["*"],
    allow_headers=["*"],
)

# Dependency to get DB session
def get_db():
    db = SessionLocal()
    try:
        yield db
    finally:
        db.close()

@app.get("/")
def read_root():
    return {"message": "Welcome to the Travel Itinerary API"}

@app.post("/itineraries/", response_model=Itinerary)
def create_itinerary(itinerary: ItineraryCreate, db: Session = Depends(get_db)):
    """Create a new itinerary"""
    db_itinerary = models.Itinerary(
        title=itinerary.title,
        description=itinerary.description,
        duration_nights=itinerary.duration_nights,
        region=itinerary.region,
        price=itinerary.price,
        is_recommended=itinerary.is_recommended
    )
    db.add(db_itinerary)
    db.commit()
    db.refresh(db_itinerary)

    # Create itinerary days
    for day_item in itinerary.days:
        db_day = models.ItineraryDay(
            day_number=day_item.day_number,
            itinerary_id=db_itinerary.id
        )
        db.add(db_day)
        db.commit()
        db.refresh(db_day)

        # Add accommodations
        if day_item.accommodation:
            db_accommodation = models.Accommodation(
                name=day_item.accommodation.name,
                location=day_item.accommodation.location,
                description=day_item.accommodation.description,
                itinerary_day_id=db_day.id
            )
            db.add(db_accommodation)

        # Add transfers
        for transfer in day_item.transfers:
            db_transfer = models.Transfer(
                from_location=transfer.from_location,
                to_location=transfer.to_location,
                transport_type=transfer.transport_type,
                duration_minutes=transfer.duration_minutes,
                itinerary_day_id=db_day.id
            )
            db.add(db_transfer)

        # Add activities
        for activity in day_item.activities:
            db_activity = models.Activity(
                name=activity.name,
                location=activity.location,
                description=activity.description,
                duration_minutes=activity.duration_minutes,
                itinerary_day_id=db_day.id
            )
            db.add(db_activity)

        db.commit()

    return db_itinerary

@app.get("/itineraries/", response_model=List[Itinerary])
def read_itineraries(skip: int = 0, limit: int = 100, db: Session = Depends(get_db)):
    """Get all itineraries"""
    itineraries = db.query(models.Itinerary).offset(skip).limit(limit).all()
    return itineraries

@app.get("/itineraries/{itinerary_id}", response_model=Itinerary)
def read_itinerary(itinerary_id: int, db: Session = Depends(get_db)):
    """Get a specific itinerary by ID"""
    itinerary = db.query(models.Itinerary).filter(models.Itinerary.id == itinerary_id).first()
    if itinerary is None:
        raise HTTPException(status_code=404, detail="Itinerary not found")
    return itinerary

@app.get("/recommended/{nights}", response_model=List[RecommendedItinerary])
def get_recommended_itineraries(nights: int, db: Session = Depends(get_db)):
    """MCP endpoint: Get recommended itineraries for a specific duration in nights"""
    if nights < 2 or nights > 8:
        raise HTTPException(status_code=400, detail="Duration must be between 2 and 8 nights")
        
    itineraries = db.query(models.Itinerary).filter(
        models.Itinerary.duration_nights == nights,
        models.Itinerary.is_recommended == True
    ).all()
    
    return itineraries

# Run with: uvicorn main:app --reload