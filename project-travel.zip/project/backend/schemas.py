from pydantic import BaseModel
from typing import List, Optional

# Accommodation Schema
class AccommodationBase(BaseModel):
    name: str
    location: str
    description: str

class AccommodationCreate(AccommodationBase):
    pass

class Accommodation(AccommodationBase):
    id: int
    itinerary_day_id: int

    class Config:
        orm_mode = True

# Transfer Schema
class TransferBase(BaseModel):
    from_location: str
    to_location: str
    transport_type: str
    duration_minutes: int

class TransferCreate(TransferBase):
    pass

class Transfer(TransferBase):
    id: int
    itinerary_day_id: int

    class Config:
        orm_mode = True

# Activity Schema
class ActivityBase(BaseModel):
    name: str
    location: str
    description: str
    duration_minutes: int

class ActivityCreate(ActivityBase):
    pass

class Activity(ActivityBase):
    id: int
    itinerary_day_id: int

    class Config:
        orm_mode = True

# Itinerary Day Schema
class ItineraryDayBase(BaseModel):
    day_number: int

class ItineraryDayCreate(ItineraryDayBase):
    accommodation: Optional[AccommodationCreate] = None
    transfers: List[TransferCreate] = []
    activities: List[ActivityCreate] = []

class ItineraryDay(ItineraryDayBase):
    id: int
    itinerary_id: int
    accommodation: Optional[Accommodation] = None
    transfers: List[Transfer] = []
    activities: List[Activity] = []

    class Config:
        orm_mode = True

# Itinerary Schema
class ItineraryBase(BaseModel):
    title: str
    description: str
    duration_nights: int
    region: str
    price: float
    is_recommended: bool = False

class ItineraryCreate(ItineraryBase):
    days: List[ItineraryDayCreate] = []

class Itinerary(ItineraryBase):
    id: int
    days: List[ItineraryDay] = []

    class Config:
        orm_mode = True

# Recommended Itinerary Schema (for MCP)
class RecommendedItinerary(BaseModel):
    id: int
    title: str
    description: str
    duration_nights: int
    region: str
    price: float

    class Config:
        orm_mode = True