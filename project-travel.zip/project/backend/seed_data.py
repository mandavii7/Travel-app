import models
from database import engine

# Create tables if they don't exist
models.Base.metadata.create_all(bind=engine)

# Seed script is in seed.py
print("Run the seed.py script to populate the database")