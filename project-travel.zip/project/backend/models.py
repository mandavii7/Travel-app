from sqlalchemy import Boolean, Column, ForeignKey, Integer, String, Float, Text
from sqlalchemy.orm import relationship
from database import Base

class Itinerary(Base):
    __tablename__ = "itineraries"

    id = Column(Integer, primary_key=True, index=True)
    title = Column(String, index=True)
    description = Column(Text)
    duration_nights = Column(Integer)
    region = Column(String, index=True)
    price = Column(Float)
    is_recommended = Column(Boolean, default=False)
    
    # Relationships
    days = relationship("ItineraryDay", back_populates="itinerary", cascade="all, delete-orphan")

class ItineraryDay(Base):
    __tablename__ = "itinerary_days"

    id = Column(Integer, primary_key=True, index=True)
    day_number = Column(Integer)
    itinerary_id = Column(Integer, ForeignKey("itineraries.id"))
    
    # Relationships
    itinerary = relationship("Itinerary", back_populates="days")
    accommodation = relationship("Accommodation", back_populates="day", uselist=False, cascade="all, delete-orphan")
    transfers = relationship("Transfer", back_populates="day", cascade="all, delete-orphan")
    activities = relationship("Activity", back_populates="day", cascade="all, delete-orphan")

class Accommodation(Base):
    __tablename__ = "accommodations"

    id = Column(Integer, primary_key=True, index=True)
    name = Column(String)
    location = Column(String)
    description = Column(Text)
    itinerary_day_id = Column(Integer, ForeignKey("itinerary_days.id"))
    
    # Relationships
    day = relationship("ItineraryDay", back_populates="accommodation")

class Transfer(Base):
    __tablename__ = "transfers"

    id = Column(Integer, primary_key=True, index=True)
    from_location = Column(String)
    to_location = Column(String)
    transport_type = Column(String)  # e.g., "car", "boat", "flight"
    duration_minutes = Column(Integer)
    itinerary_day_id = Column(Integer, ForeignKey("itinerary_days.id"))
    
    # Relationships
    day = relationship("ItineraryDay", back_populates="transfers")

class Activity(Base):
    __tablename__ = "activities"

    id = Column(Integer, primary_key=True, index=True)
    name = Column(String)
    location = Column(String)
    description = Column(Text)
    duration_minutes = Column(Integer)
    itinerary_day_id = Column(Integer, ForeignKey("itinerary_days.id"))
    
    # Relationships
    day = relationship("ItineraryDay", back_populates="activities")