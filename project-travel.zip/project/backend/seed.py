import models
from database import SessionLocal, engine
import random

# Create tables
models.Base.metadata.create_all(bind=engine)

db = SessionLocal()

# Clear existing data
db.query(models.Activity).delete()
db.query(models.Transfer).delete()
db.query(models.Accommodation).delete()
db.query(models.ItineraryDay).delete()
db.query(models.Itinerary).delete()
db.commit()

# Seed data for Phuket
phuket_hotels = [
    {"name": "Anantara Layan Phuket Resort", "location": "Layan Beach", 
     "description": "Luxury beachfront resort with private pool villas"},
    {"name": "Amari Phuket", "location": "Patong Beach", 
     "description": "Elegant resort on a secluded beach with stunning views"},
    {"name": "The Slate", "location": "Nai Yang Beach", 
     "description": "Design-focused luxury resort with unique architecture"},
    {"name": "Keemala", "location": "Kamala", 
     "description": "Unique eco-friendly resort with tree houses and pool villas"}
]

phuket_activities = [
    {"name": "Phi Phi Islands Tour", "location": "Phi Phi Islands", 
     "description": "Day trip to the stunning Phi Phi Islands with snorkeling", "duration_minutes": 480},
    {"name": "Big Buddha Visit", "location": "Chalong", 
     "description": "Visit the iconic 45m tall white marble Buddha statue", "duration_minutes": 180},
    {"name": "Old Phuket Town Walking Tour", "location": "Phuket Town", 
     "description": "Explore the Sino-Portuguese architecture and local culture", "duration_minutes": 240},
    {"name": "Patong Beach Day", "location": "Patong", 
     "description": "Relax at Phuket's most famous beach with water activities", "duration_minutes": 360},
    {"name": "Phang Nga Bay Tour", "location": "Phang Nga Bay", 
     "description": "Boat tour of the spectacular limestone karsts and caves", "duration_minutes": 420},
    {"name": "Phuket Night Market", "location": "Various locations", 
     "description": "Experience local food and crafts at a bustling night market", "duration_minutes": 180}
]

# Seed data for Krabi
krabi_hotels = [
    {"name": "Rayavadee", "location": "Railay Beach", 
     "description": "Luxury resort set amidst tropical gardens and limestone cliffs"},
    {"name": "Pimalai Resort & Spa", "location": "Koh Lanta", 
     "description": "Beachfront sanctuary with panoramic views of the Andaman Sea"},
    {"name": "Centara Grand Beach Resort & Villas", "location": "Ao Nang", 
     "description": "Elegant resort located in a private bay accessible only by boat"},
    {"name": "The Tubkaak Krabi Boutique Resort", "location": "Tubkaak Beach", 
     "description": "Romantic boutique hotel with views of the Hong Islands"}
]

krabi_activities = [
    {"name": "Four Islands Tour", "location": "Krabi", 
     "description": "Visit Chicken, Tup, Mor and Poda Islands with snorkeling", "duration_minutes": 420},
    {"name": "Emerald Pool and Hot Springs", "location": "Thung Teao Forest", 
     "description": "Swim in the natural emerald-colored pool and relax in hot springs", "duration_minutes": 300},
    {"name": "Rock Climbing at Railay", "location": "Railay Beach", 
     "description": "Climb the world-famous limestone cliffs with professional guides", "duration_minutes": 240},
    {"name": "Tiger Cave Temple", "location": "Krabi Town", 
     "description": "Climb 1,237 steps to the summit for panoramic views", "duration_minutes": 180},
    {"name": "Hong Island Kayaking", "location": "Hong Islands", 
     "description": "Kayak around the stunning Hong Islands and hidden lagoons", "duration_minutes": 360},
    {"name": "Ao Nang Elephant Sanctuary", "location": "Ao Nang", 
     "description": "Ethical elephant sanctuary visit with feeding and bathing", "duration_minutes": 240}
]

# Transport types
transport_types = ["Private car", "Speedboat", "Ferry", "Longtail boat", "Minivan"]

# Create itineraries for different durations
for nights in range(2, 9):
    # Create Phuket itinerary
    phuket_itinerary = models.Itinerary(
        title=f"{nights}-Night Phuket Adventure",
        description=f"Experience the best of Phuket with this {nights}-night itinerary covering beaches, culture, and adventure",
        duration_nights=nights,
        region="Phuket",
        price=float(random.randint(300, 500) * nights),
        is_recommended=True
    )
    db.add(phuket_itinerary)
    db.commit()
    db.refresh(phuket_itinerary)
    
    # Create days for Phuket itinerary
    for day in range(1, nights + 2):  # +2 because checkout day counts
        phuket_day = models.ItineraryDay(
            day_number=day,
            itinerary_id=phuket_itinerary.id
        )
        db.add(phuket_day)
        db.commit()
        db.refresh(phuket_day)
        
        # Add accommodation (except for last day which is checkout)
        if day < nights + 1:
            hotel = random.choice(phuket_hotels)
            accommodation = models.Accommodation(
                name=hotel["name"],
                location=hotel["location"],
                description=hotel["description"],
                itinerary_day_id=phuket_day.id
            )
            db.add(accommodation)
        
        # Add activities (1-3 per day)
        num_activities = random.randint(1, min(3, len(phuket_activities)))
        day_activities = random.sample(phuket_activities, num_activities)
        
        for activity_data in day_activities:
            activity = models.Activity(
                name=activity_data["name"],
                location=activity_data["location"],
                description=activity_data["description"],
                duration_minutes=activity_data["duration_minutes"],
                itinerary_day_id=phuket_day.id
            )
            db.add(activity)
        
        # Add transfers (1-2 per day)
        num_transfers = random.randint(0, 2)
        for _ in range(num_transfers):
            from_loc = random.choice(["Hotel", "Airport"] + [a["location"] for a in phuket_activities])
            to_loc = random.choice([a["location"] for a in phuket_activities] + ["Hotel", "Restaurant"])
            # Avoid same locations
            while to_loc == from_loc:
                to_loc = random.choice([a["location"] for a in phuket_activities] + ["Hotel", "Restaurant"])
                
            transfer = models.Transfer(
                from_location=from_loc,
                to_location=to_loc,
                transport_type=random.choice(transport_types),
                duration_minutes=random.randint(20, 90),
                itinerary_day_id=phuket_day.id
            )
            db.add(transfer)
    
    # Create Krabi itinerary
    krabi_itinerary = models.Itinerary(
        title=f"{nights}-Night Krabi Explorer",
        description=f"Discover the natural beauty of Krabi with this {nights}-night itinerary featuring beaches, islands, and adventure",
        duration_nights=nights,
        region="Krabi",
        price=float(random.randint(250, 450) * nights),
        is_recommended=True
    )
    db.add(krabi_itinerary)
    db.commit()
    db.refresh(krabi_itinerary)
    
    # Create days for Krabi itinerary
    for day in range(1, nights + 2):  # +2 because checkout day counts
        krabi_day = models.ItineraryDay(
            day_number=day,
            itinerary_id=krabi_itinerary.id
        )
        db.add(krabi_day)
        db.commit()
        db.refresh(krabi_day)
        
        # Add accommodation (except for last day which is checkout)
        if day < nights + 1:
            hotel = random.choice(krabi_hotels)
            accommodation = models.Accommodation(
                name=hotel["name"],
                location=hotel["location"],
                description=hotel["description"],
                itinerary_day_id=krabi_day.id
            )
            db.add(accommodation)
        
        # Add activities (1-3 per day)
        num_activities = random.randint(1, min(3, len(krabi_activities)))
        day_activities = random.sample(krabi_activities, num_activities)
        
        for activity_data in day_activities:
            activity = models.Activity(
                name=activity_data["name"],
                location=activity_data["location"],
                description=activity_data["description"],
                duration_minutes=activity_data["duration_minutes"],
                itinerary_day_id=krabi_day.id
            )
            db.add(activity)
        
        # Add transfers (1-2 per day)
        num_transfers = random.randint(0, 2)
        for _ in range(num_transfers):
            from_loc = random.choice(["Hotel", "Airport"] + [a["location"] for a in krabi_activities])
            to_loc = random.choice([a["location"] for a in krabi_activities] + ["Hotel", "Restaurant"])
            # Avoid same locations
            while to_loc == from_loc:
                to_loc = random.choice([a["location"] for a in krabi_activities] + ["Hotel", "Restaurant"])
                
            transfer = models.Transfer(
                from_location=from_loc,
                to_location=to_loc,
                transport_type=random.choice(transport_types),
                duration_minutes=random.randint(20, 90),
                itinerary_day_id=krabi_day.id
            )
            db.add(transfer)

    # Create Phuket-Krabi combined itinerary for 5+ nights
    if nights >= 5:
        combined_itinerary = models.Itinerary(
            title=f"{nights}-Night Phuket & Krabi Adventure",
            description=f"The best of both worlds! Experience Phuket and Krabi in this {nights}-night combined itinerary",
            duration_nights=nights,
            region="Phuket & Krabi",
            price=float(random.randint(350, 550) * nights),
            is_recommended=True
        )
        db.add(combined_itinerary)
        db.commit()
        db.refresh(combined_itinerary)
        
        # Split the stay between regions
        phuket_nights = nights // 2
        krabi_nights = nights - phuket_nights
        
        # Create days for combined itinerary
        for day in range(1, nights + 2):  # +2 because checkout day counts
            combined_day = models.ItineraryDay(
                day_number=day,
                itinerary_id=combined_itinerary.id
            )
            db.add(combined_day)
            db.commit()
            db.refresh(combined_day)
            
            # Decide region based on day number
            in_phuket = day <= phuket_nights + 1  # +1 for the transfer day
            current_region = "Phuket" if in_phuket else "Krabi"
            hotels = phuket_hotels if in_phuket else krabi_hotels
            activities_list = phuket_activities if in_phuket else krabi_activities
            
            # Add accommodation (except for last day which is checkout)
            if day < nights + 1:
                # On transfer day from Phuket to Krabi, use Krabi hotel
                if day == phuket_nights + 1:
                    hotel = random.choice(krabi_hotels)
                else:
                    hotel = random.choice(hotels)
                    
                accommodation = models.Accommodation(
                    name=hotel["name"],
                    location=hotel["location"],
                    description=hotel["description"],
                    itinerary_day_id=combined_day.id
                )
                db.add(accommodation)
            
            # Add special transfer between regions on the transfer day
            if day == phuket_nights + 1:
                transfer = models.Transfer(
                    from_location="Phuket",
                    to_location="Krabi",
                    transport_type="Ferry",
                    duration_minutes=180,
                    itinerary_day_id=combined_day.id
                )
                db.add(transfer)
                # Fewer activities on transfer day
                num_activities = 1
            else:
                # Regular activities (1-3 per day)
                num_activities = random.randint(1, min(3, len(activities_list)))
                
            day_activities = random.sample(activities_list, num_activities)
            for activity_data in day_activities:
                activity = models.Activity(
                    name=activity_data["name"],
                    location=activity_data["location"],
                    description=activity_data["description"],
                    duration_minutes=activity_data["duration_minutes"],
                    itinerary_day_id=combined_day.id
                )
                db.add(activity)
            
            # Add regular transfers (except on the region transfer day)
            if day != phuket_nights + 1:
                num_transfers = random.randint(0, 2)
                for _ in range(num_transfers):
                    from_loc = random.choice(["Hotel", "Airport"] + [a["location"] for a in activities_list])
                    to_loc = random.choice([a["location"] for a in activities_list] + ["Hotel", "Restaurant"])
                    # Avoid same locations
                    while to_loc == from_loc:
                        to_loc = random.choice([a["location"] for a in activities_list] + ["Hotel", "Restaurant"])
                        
                    transfer = models.Transfer(
                        from_location=from_loc,
                        to_location=to_loc,
                        transport_type=random.choice(transport_types),
                        duration_minutes=random.randint(20, 90),
                        itinerary_day_id=combined_day.id
                    )
                    db.add(transfer)

db.commit()
db.close()

print("Database seeded successfully!")